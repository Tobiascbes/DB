CREATE DATABASE TEC;

USE TEC
CREATE TABLE Students (
    StudentID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL
);

CREATE TABLE Teachers (
    TeacherID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL
);

CREATE TABLE Courses (
    CourseID INT PRIMARY KEY,
    Title VARCHAR(255) NOT NULL,
    TeacherID INT NOT NULL,
    CONSTRAINT FK_Teachers_Courses FOREIGN KEY (TeacherID) REFERENCES Teachers(TeacherID)
);

CREATE TABLE Registration (
    StudentID INT NOT NULL,
    CourseID INT NOT NULL,
    CONSTRAINT FK_Students_Registration FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    CONSTRAINT FK_Courses_Registration FOREIGN KEY (CourseID) REFERENCES Courses(CourseID),
    PRIMARY KEY (StudentID, CourseID)
);

INSERT INTO Students (StudentID, Name)
VALUES
(1, 'Alexander Mathias Thamdrup'),
(2, 'Allan Gawron'),
(3, 'Andreas Carl Balle'),
(4, 'Darab Haqnazar'),
(5, 'Felix Enok Berger'),
(6, 'Jamie Jamahl De la sencerie El-Dessouky'),
(7, 'Jeppe Carlseng Pedersen'),
(8, 'Joseph Hollad-Hale'),
(9, 'Kamil Marcin Kulpa'),
(10, 'Loke Emil Bendtsen'),
(11, 'Mark Hyrsting Larsen'),
(12, 'Niklas Kim Jensen'),
(13, 'Rasmus Peter Hjorth'),
(14, 'Sammy Damiri'),
(15, 'Thomas Mose Holmberg'),
(16, 'Tobias Casanas Besser'),
(17, 'Tobias Kofoed Larsen');

INSERT INTO Teachers (TeacherID, Name)
VALUES
(1, 'Niels Olesen'),
(2, 'Flemming Soerensen'),
(3, 'Peter Suni Lindenskov'),
(4, 'Henrik Vincents Poulsen');

INSERT INTO Courses (CourseID, Title, TeacherID)
VALUES
(1, 'Studie Teknik', 1),
(2, 'Grundl�ggene programmering', 1),
(3, 'Database Programmering', 1),
(4, 'Computer Teknologi', 1),
(5, 'Object Orienteret Programmering', 2),
(6, 'Clientside programmering', 3),
(7, 'Netv�rk', 4);

INSERT INTO Registration (StudentID, CourseID)
SELECT s.StudentID, c.CourseID
FROM Students s, Courses c;
