﻿using System.Data.SqlClient;
using System.Reflection.PortableExecutable;

namespace TeacherSearch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Connect to Database
            string ConnectionString = "server = (LocalDB)\\MSSQLLocalDB; uid = Tobias; pwd = Password; DATABASE = TEC; Trusted_Connection=True;";
            SqlConnection conn = new SqlConnection(ConnectionString);

            Console.Write("Indtast lærerens navn: ");
            string nameInput = Console.ReadLine();
            conn.Open();
            int ID = FindTeacer(conn, nameInput);

            List<int> courseIDs = FindCourses(conn, ID);
            foreach (int courseID in courseIDs)
            {
                List<int> studentIDs = FindRegistration(conn, courseID);
                foreach (int studentID in studentIDs)
                {
                    FindStudents(conn, studentID);
                }
            }

            conn.Close();

            Console.ReadKey();
        }
        static int FindTeacer(SqlConnection conn, string input)
        {
            SqlCommand cmd = new SqlCommand($"SELECT * FROM Teachers WHERE [Name] = \'{input}\';", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            int id = 0;
            if (reader.Read())
            {
                Console.WriteLine($"[{reader.GetValue(0)}] Lærer: {reader.GetValue(1)}");
                id = reader.GetInt32(0);
            }
            else
            {
                Console.WriteLine("Læreren findes ikke");
            }

            cmd.Dispose();
            reader.Close();
            return id;
        }

        static List<int> FindCourses(SqlConnection conn, int courseID)
        {
            List<int> courseIDs = new List<int>();
            SqlCommand cmd2 = new($"SELECT * FROM Courses WHERE TeacherID = {courseID}", conn);
            SqlDataReader reader = cmd2.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine($"[{reader.GetValue(0)}] Fag: {reader.GetValue(1)}");
                courseIDs.Add(reader.GetInt32(0));
            }

            cmd2.Dispose();
            reader.Close();

            return courseIDs;
        }

        static List<int> FindRegistration(SqlConnection conn, int courseID)
        {
            List<int> studentIDs = new();
            SqlCommand cmd4 = new($"SELECT StudentID FROM Registration WHERE CourseID = {courseID}", conn);
            SqlDataReader reader = cmd4.ExecuteReader();
            while (reader.Read())
            {
                studentIDs.Add(reader.GetInt32(0));
            }

            cmd4.Dispose();
            reader.Close();

            return studentIDs;
        }

        static void FindStudents(SqlConnection conn, int studentID)
        {
            SqlCommand cmd3 = new($"SELECT * FROM Students WHERE StudentID = {studentID}", conn);
            SqlDataReader reader = cmd3.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine($"[{reader.GetValue(0)}] Elev: {reader.GetValue(1)}");
            }

            cmd3.Dispose();
            reader.Close();
        }
    }
}